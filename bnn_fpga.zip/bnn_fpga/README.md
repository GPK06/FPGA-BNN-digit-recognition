# BNN 784-256-256-10 : Verilog + Vivado simulation + Zedboard demo

```
rtl/bnn_layer.v        one binarized FC layer (XNOR-popcount, 64 inputs/clk, 1 neuron at a time)
rtl/bnn_top.v          3 layers chained; start/done handshake; raw-sum argmax
rtl/zed_demo_top.v     Zedboard demo (images in BRAM, BTNC/SW0, LEDs)   + rtl/btn_debounce.v
sim/tb_bnn_top.v       self-checking TB: 1000 images vs expected_pred.mem (must be 1000/1000)
sim/tb_zed_demo.v      smoke test of the wrapper (shortened timers)
constraints/zedboard.xdc
scripts/               vivado_sim.tcl, vivado_build.tcl, run_iverilog.sh, verify_mem.py
mem/                   your 8 .mem files
```

## Conventions implemented (and where)
* **Weights**: `1` -> +1, `0` -> -1. Input 0 = LEFTMOST character. `$readmemb` puts it in the MSB, so
  input *i* is `w_row[N-1-i]`; handled in `bnn_layer.v` (and `pix[k] = img[783-k]` in the TB / wrapper).
* **Thresholds**: 11-bit two's complement, signed compare `x >= T`, `x = 2*popcount(XNOR) - N`. No flip flag.
* **Output layer**: raw sums, no thresholds, streaming argmax with strict `>` -> lowest index wins ties
  (matches `np.argmax`; it matters for images 495 and 959 in your set).
* **Input**: pixel >= 128 -> 1; pixel 0 = top-left, row-major.

## Run the simulation in Vivado (xsim)
Fast way (batch):
```
cd bnn_fpga
vivado -mode batch -source scripts/vivado_sim.tcl
```
GUI way: Create project (part `xc7z020clg484-1`) -> add `rtl/*.v` as design sources, `sim/tb_bnn_top.v`
as simulation source, and **add all `mem/*.mem` as simulation sources too** -> Run Simulation.
If you get `Unable to open ... .mem`, copy the `.mem` files into `<proj>.sim/sim_1/behav/xsim/`
(that is the directory `$readmemb` resolves relative paths against).

Expected console output:
```
 match vs expected_pred  : 1000 / 1000
 accuracy vs test_labels : 972 / 1000 (97.2 %)
 latency (cycles/image)  : min 5961  max 5961
 RESULT: TEST PASSED (bit-exact)
```
Simulation time: roughly 6 M clock cycles, a few minutes. For a quick check set `N_IMAGES` (e.g. 20) on
`tb_bnn_top`; `VERBOSE=1` prints every image with its raw winning score.

Open-source cross-check: `scripts/run_iverilog.sh` (same files). `python3 scripts/verify_mem.py`
re-derives expected_pred from the .mem files with NumPy.

## Build and run on the Zedboard
```
vivado -mode batch -source scripts/vivado_build.tcl      # -> vivado_impl/.../zed_demo_top.bit
```
Program the PL via JTAG (Hardware Manager). Zedboard jumpers must be set for JTAG/Cascaded mode as
usual. BTNC = next image, SW0 = free-run (~2 img/s), BTNU = reset.
LD[3:0] = prediction, LD[7:4] = true label (binary): equal nibbles = correct.

## Design notes
* Cycles/image = 5961 (4096 + 1792 + 70 + start/handshake) = ~60 us @ 100 MHz.
* Resources (estimate): ~11 BRAM36 for W0, ~2 for W1, 22 for the image ROM, a few hundred LUTs of
  logic. Check `utilization.rpt`.
* A fully-parallel version (784-bit popcount per neuron, all 256 neurons) would not fit the Z-7020; this
  folded design trades speed for area.
